<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body  onload="window.print();">
<table style="border-collapse:collapse;width:245px;" border="0">
	<tr style="text-align:center">
		<td colspan="4"><b>TITLE</b></td>
	</tr>
	<tr style="text-align:center;font-size:11px;">
		<td colspan="4">AddressLine 1</td>
	</tr>
	<tr style="text-align:center;font-size:11px;">
		<td colspan="4">Phone number</td>
	</tr>
	<tr style="text-align:center;font-size:11px;">
		<td colspan="4">Other data</td>
	</tr>
	<tr style="text-align:center">
		<td>Qty</td>
		<td>Price</td>
		<td>Dis</td>
		<td>Amount</td>
	</tr>
	<tr>
		<td colspan="3">Product appear name</td>
		<td></td>
	</tr>
	<tr>
		<td>1</td>
		<td>250</td>
		<td>6%</td>
		<td style="text-align:right">2300</td>
	</tr>
	<tr>
		<td>2</td>
		<td>250</td>
		<td>6%</td>
		<td style="text-align:right">2300</td>
	</tr>
	<tr>
		<td>3</td>
		<td>250</td>
		<td>6%</td>
		<td style="text-align:right">2300</td>
	</tr>
	<tr>
		<td colspan="2">Total Amount</td>
		<td></td>
		<td style="text-align:right">4500</td>
	</tr>
	<tr>
		<td colspan="2">Total Discount</td>
		<td></td>
		<td style="text-align:right">4500</td>
	</tr>
	<tr>
		<td colspan="2">Net Amount</td>
		<td></td>
		<td style="text-align:right">4500</td>
	</tr>
	<tr>
		<td colspan="2">Customer Pay</td>
		<td></td>
		<td style="text-align:right">4500</td>
	</tr>
	<tr>
		<td colspan="2">Balance Amount</td>
		<td></td>
		<td style="text-align:right">4500</td>
	</tr>
	<tr>
		<td colspan="2">Number of Itm</td>
		<td></td>
		<td style="text-align:right">4500</td>
	</tr>
	<tr style="text-align:center">
		<td colspan="4">Thank You Come Again</td>
	</tr>
</table>
</body>
</html>