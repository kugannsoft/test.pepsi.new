<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>

            <footer class="main-footer">
                <div class="pull-right hidden-xs">
                    <b><?php echo lang('footer_version'); ?></b> 1.3.0
                </div>
                <strong><?php echo lang('footer_copyright'); ?> &copy; 2014-<?php echo date('Y'); ?> <a href="http://nsoft.lk" target="_blank">Nsoft</a> .</strong> <?php echo lang('footer_all_rights_reserved'); ?>.
            </footer>
        </div>

        
    </body>
</html>